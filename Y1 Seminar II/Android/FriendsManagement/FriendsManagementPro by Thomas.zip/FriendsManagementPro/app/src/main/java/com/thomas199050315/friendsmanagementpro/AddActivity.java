package com.thomas199050315.friendsmanagementpro;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static android.util.TypedValue.COMPLEX_UNIT_SP;

public class AddActivity extends AppCompatActivity {

    public static final String EXTRA_FRIEND_ID = "FriendID" ;
    private TableLayout mTableLayout;
    private Button mDateButton;
    private EditText mNameEdit;
    private Button mSaveButton;
    private Button mCancelButton;
    private RadioButton mRadioButtonMan;
    private RadioButton mRadioButtonWoman;
    private List<CheckBox> mHobbys;
    private Friend mFriend;
    private Date mDate;
    //用于显示日期对话框，并缓存到mDate中。
    private void GetDate(){
        Calendar cal = Calendar.getInstance();
        cal.setTime(mFriend.getDate());
        DatePickerDialog dialog =new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Calendar cal = Calendar.getInstance();
                cal.set(year,month,dayOfMonth);
                mDate = cal.getTime();
                String date = (String) DateFormat.format("yyyy 年MM 月dd 日", mDate);
                mDateButton.setText(date);
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        UUID Id=(UUID)getIntent().getSerializableExtra(EXTRA_FRIEND_ID);
        //获取mFriend对象
        if (Id == null){
            mFriend = new Friend();
        }else
        {
            mFriend = FriendLab.get(AddActivity.this).getFriend(Id);
        }
        mDate = mFriend.getDate();
        mHobbys = new ArrayList<>();
        //用来存放InitTable()方法中动态创建的所有兴趣checkbox的引用
        mDateButton = findViewById(R.id.button_Date);
        String date = (String) DateFormat.format("yyyy 年MM月dd 日", mDate);
        mDateButton.setText(date);
        mDateButton.setOnClickListener
                (new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        GetDate();
                    }
                });
        mRadioButtonMan = findViewById(R.id.radioButton_man);
        mRadioButtonWoman = findViewById(R.id.radioButton_woman);
        if (mFriend.getSex() == 1 ){
            mRadioButtonWoman.setChecked(true);
        }
        mSaveButton = findViewById(R.id.savebutton);
        mSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SaveFriend();
                finish();
            }
        });
        mCancelButton = findViewById(R.id.cancelbutton);
        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mNameEdit = findViewById(R.id.editText_name);
        mNameEdit.setText(mFriend.getName());
        //自动生成爱好列表的checkbox群
        InitTable();
        //将爱好列表的字符串解析到checkbox群中显示出来
        LoadHobby();
    }

    private void InitTable(){
        //初始化爱好列表
        mTableLayout = findViewById(R.id.Table_Layout);
        CheckBox btn;
        TableRow row= new TableRow(this);
        TableRow.LayoutParams param1 = new TableRow.LayoutParams();
        param1.setMargins(20,8,8,8);
        for(int i=1;i<= Friend.hobbys.length;i++)
        {
            btn = new CheckBox(this);
            btn.setText(Friend.hobbys[i-1]);
            btn.setPadding(8,8,8,8);
            btn.setTextSize(COMPLEX_UNIT_SP,18);
            btn.setLayoutParams(param1);
            btn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int mCount=0;
                    for (CheckBox c:mHobbys) {
                        if (c.isChecked())mCount++; }
                    if(mCount>3) buttonView.setChecked(false);
                }
            });
            mHobbys.add(btn);
            row.addView(btn);
            if(i%3==0){
                mTableLayout.addView(row);
                row= new TableRow(this);
            }
        }
        mTableLayout.addView(row);
    }

    //将缓存的数据保存到Friend对象中 点击保存按钮，运行此方法，再运行finish()关闭activity。
    private void SaveFriend() {
        mFriend.setName(mNameEdit.getText().toString());
        mFriend.setDate(mDate);
        mFriend.setSex(mRadioButtonMan.isChecked()?0:1);
        SaveHobby();
        //检查是否是新增的Friend
        if (FriendLab.get(AddActivity.this).getFriend(mFriend.getId())==null){
            FriendLab.get(AddActivity.this).getFriends().add(mFriend);
        };
    }

    //从界面上解析，保存爱好
    private void SaveHobby(){
        String sHobby = "" ;
        for (CheckBox c:mHobbys) {
            if (c.isChecked()){
                sHobby =sHobby+c.getText()+" " ;
            }
        }
        mFriend.setHobby(sHobby);
    }

    //读取爱好，显示到界面上
    private void LoadHobby(){
        String sHobby =mFriend.getHobby();
        if (sHobby==null)return;
        for
        (CheckBox c:mHobbys) {
            if (sHobby.indexOf(c.getText().toString())!= -1){
                c.setChecked(true);
            }
        }
    }

    public static Intent newIntent(Context context, UUID FriendId){
        Intent intent = new Intent(context,AddActivity.class);
        intent.putExtra(EXTRA_FRIEND_ID,FriendId);
        return intent;
    }
}
