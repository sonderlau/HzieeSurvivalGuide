package com.thomas199050315.friendsmanagementpro;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private String[][] constellations = {{"摩羯座", "水瓶座"}, {"水瓶座", "双鱼座"}, {"双鱼座", "白羊座"}, {"白羊座", "金牛座"},
            {"金牛座", "双子座"}, {"双子座", "巨蟹座"}, {"巨蟹座", "狮子座"}, {"狮子座", "处女座"}, {"处女座", "天秤座"}, {"天秤座", "天蝎座"},
            {"天蝎座", "射手座"}, {"射手座", "摩羯座"}};
    //1-12每个月的星座分割日期
    private int[] date = {20, 19, 21, 20, 21, 22, 23, 23, 23, 24, 23, 22};
    private RecyclerView mFriendRecyclerView;
    private FriendAdapter mAdapter;
    //计算星座
    private String getConstellations(int Month,int Day) {
        int day = date[Month - 1];
        return constellations[Month- 1][Day >= day?1:0];
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(0,1,0, "修改");
        menu.add(0,2,0, "删除");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case 1:
                Intent intent = AddActivity.newIntent(MainActivity.this, FriendLab.get(MainActivity.this).getFriends().get(mAdapter.mPosition).getId());
                startActivity(intent);
                break;
            case 2:
                FriendLab.get(MainActivity.this).getFriends().remove(mAdapter.mPosition);
                mAdapter.notifyItemRemoved(mAdapter.mPosition);
                updateUI();
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFriendRecyclerView = findViewById(R.id.friend_recycler_view);
        mFriendRecyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        mFriendRecyclerView.setLongClickable(true);
        updateUI();
    }

    private void updateUI() {
        FriendLab friendLab = FriendLab.get(MainActivity.this);
        List<Friend> Friends = friendLab.getFriends();
        if (mAdapter == null) {
            mAdapter = new FriendAdapter(Friends);
            mFriendRecyclerView.setAdapter(mAdapter);
        } else {
            mAdapter.notifyDataSetChanged();
        }
        getSupportActionBar().setSubtitle(String.format("共有%d位好友", FriendLab.get(MainActivity.this).getFriends().size()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }

    private class FriendHolder extends RecyclerView.ViewHolder
    {
        private Friend mFriend;
        private TextView mTitleTextView;
        private TextView mTagTextView;
        private TextView mHobbyTextView;
        public FriendHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_friend, parent, false));
            mTitleTextView = itemView.findViewById(R.id.editText_name);
            mTagTextView = itemView.findViewById(R.id.friend_tag);
            mHobbyTextView = itemView.findViewById(R.id.friend_hobby);
            registerForContextMenu(itemView);
        }
        public void bind(Friend Friend) {
            int mYear,mAge;
            String Sex,Constellations;
            mFriend = Friend;
            mTitleTextView.setText(mFriend.getName());
            Sex = mFriend.getSex()== 0 ? " 男 " : " 女 " ;
            Calendar fromCalendar = Calendar.getInstance();
            //获取当前年份
            fromCalendar.setTime(new Date());
            mYear = fromCalendar.get(Calendar.YEAR);
            //获取年龄（当前年份-出生年份）
            fromCalendar.setTime(mFriend.getDate());
            mAge = mYear -fromCalendar.get(Calendar.YEAR);
            //获取星座
            Constellations = getConstellations(fromCalendar.get(Calendar.MONTH)+ 1,fromCalendar.get(Calendar.DAY_OF_MONTH));
            mTagTextView.setText(Sex+" " +String.valueOf(mAge)+ "岁"+ Constellations);
            mHobbyTextView.setText(mFriend.getHobby());
        }
    }

    private class FriendAdapter extends RecyclerView.Adapter<FriendHolder> {
        private List<Friend> mFriends;
        private int mPosition;
        public FriendAdapter(List<Friend> Friends) {
            mFriends = Friends;
        }
        @Override
        public FriendHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
            return new FriendHolder(layoutInflater, parent);
        }
        @Override
        public void onBindViewHolder(final FriendHolder holder, int position) {
            final Friend Friend = mFriends.get(position);
            holder.bind(Friend);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = AddActivity.newIntent(MainActivity.this,Friend.getId());
                    startActivity(intent);
                }
            });
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    mPosition = holder.getAdapterPosition();
                    return false;
                }
            });
        }
        @Override
        public int getItemCount() {
            return mFriends.size();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = AddActivity.newIntent(MainActivity.this,null);
        startActivity(intent);
        return super.onOptionsItemSelected(item);
    }
}
