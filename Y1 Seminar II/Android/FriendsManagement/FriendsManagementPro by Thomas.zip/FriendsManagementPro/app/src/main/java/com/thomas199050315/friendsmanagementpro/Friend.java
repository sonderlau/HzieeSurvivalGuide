package com.thomas199050315.friendsmanagementpro;

import java.util.Date;
import java.util.UUID;

public class Friend {
    public static final String[] hobbys = {"电影", "编程", "篮球", "足球", "游泳", "羽毛球", "绘画", "写作", "美食", "游戏", "购物", "阅读", "登山", "旅行"};
    private UUID mId;
    private String mName;
    private int mSex;
    private Date mDate;
    private String mHobby;

    public Friend() {
        mId = UUID.randomUUID();
        mDate = new Date();
    }

    public UUID getId() {
        return mId;
    }

    public static String[] getHobbys() {
        return hobbys;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public int getSex() {
        return mSex;
    }

    public void setSex(int sex) {
        mSex = sex;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public String getHobby() {
        return mHobby;
    }

    public void setHobby(String hobby) {
        mHobby = hobby;
    }
}
