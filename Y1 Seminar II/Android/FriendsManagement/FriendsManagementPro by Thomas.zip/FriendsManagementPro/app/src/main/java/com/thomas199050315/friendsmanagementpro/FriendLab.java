package com.thomas199050315.friendsmanagementpro;

import android.content.Context;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class FriendLab
{
    private static FriendLab sFriendLab;

    private List<Friend> mFriends;

    public static FriendLab get(Context context) {
        if (sFriendLab == null) {
            sFriendLab = new FriendLab(context);
        }
        return sFriendLab;
    }

    private FriendLab(Context context) {
        mFriends = new ArrayList<>();
        //产生一些随机数据供显示。
        for (int i = 0; i < 30; i++) {
            Friend Friend = new Friend();
            Friend.setName("Friend #" + (i+ 1)); //i+1可以从1开始显示
            Friend.setHobby(Friend.hobbys[0]+ " " +Friend.hobbys[1]+ " " +Friend.hobbys[2]);
            Friend.setDate(new Date(1L *1000 *3600 *24 *365 *30));
            Friend.setSex(i% 2);
            mFriends.add(Friend);
        }
    }

    public List<Friend> getFriends() {
        return mFriends;
    }

    public Friend getFriend(UUID id) {
        for (Friend friend :mFriends){
            if (friend.getId().equals(id)){
                return friend;
            }
        }
        return null;
    }
}
